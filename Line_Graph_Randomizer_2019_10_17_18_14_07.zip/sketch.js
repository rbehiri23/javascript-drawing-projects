function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(256);
  strokeWeight(5);
  let rstrk = random(200);
  let start = 0;
  for(i = 0; i < 100; i++){
    stroke(rstrk);
    length = random(-200,200);
    start = random(195,205)
    line(start, i * 5, 200 + length, i * 5);
    stroke(rstrk - 50);
    line(start, i * 5, 200 + length + 50, i * 5);
  }
}
